from resources.lib import settings

settings.set_trailer_context()
